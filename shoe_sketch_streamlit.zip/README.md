# Shoe Sketch to Product Image

A Streamlit app based on the provided Colab notebook. It accepts a shoe sketch and generates a product-style image using pretrained Stable Diffusion 1.5 and the pretrained ControlNet scribble model.

## Open in VS Code

1. Extract `shoe_sketch_streamlit.zip`.
2. In VS Code, choose **File > Open Folder** and select the extracted `shoe_sketch_streamlit` folder.
3. Open **Terminal > New Terminal** and run:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install torch torchvision
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

If PowerShell blocks environment activation, run this in that terminal and activate again:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

The first run downloads the pretrained models and needs internet access plus several GB of disk space. A CUDA-compatible GPU is strongly recommended. CPU generation can be very slow. For CUDA-specific PyTorch installation, use the official selector at https://pytorch.org/get-started/locally/.

## Project files

- `app.py` — sketch upload, prompt controls, generation, and PNG download.
- `requirements.txt` — Python packages used by the app. Install PyTorch separately using the command above.
- `.gitignore` — excludes local virtual environment and generated/cache files.

## Model and training note

This app uses pretrained `runwayml/stable-diffusion-v1-5` and `lllyasviel/control_v11p_sd15_scribble`. The notebook prepares shoe images, sketches, and captions, but does not train or fine-tune a model. Its LoRA cell only defines a configuration; no LoRA adapter is trained or loaded here.
